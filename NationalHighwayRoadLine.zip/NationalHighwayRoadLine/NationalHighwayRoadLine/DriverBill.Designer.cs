﻿namespace NationalHighwayRoadLine
{
    partial class DriverBill
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnRefersh = new System.Windows.Forms.Button();
            this.lblid = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dbPaymentMode = new System.Windows.Forms.ComboBox();
            this.txtDriverMobno = new System.Windows.Forms.TextBox();
            this.txtDriverName = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txtAmountLeft = new System.Windows.Forms.TextBox();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.txtRate = new System.Windows.Forms.TextBox();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.txtDestination = new System.Windows.Forms.TextBox();
            this.txtPartyName = new System.Windows.Forms.TextBox();
            this.txtTruckNo = new System.Windows.Forms.TextBox();
            this.txtLRNo = new System.Windows.Forms.TextBox();
            this.txtPayPartyName = new System.Windows.Forms.TextBox();
            this.txtTripAdv = new System.Windows.Forms.TextBox();
            this.txtDieasalAdv = new System.Windows.Forms.TextBox();
            this.txtTollAmount = new System.Windows.Forms.TextBox();
            this.lblPayPartyName = new System.Windows.Forms.Label();
            this.lblPayMode = new System.Windows.Forms.Label();
            this.lblAmtLeft = new System.Windows.Forms.Label();
            this.lblTripAdv = new System.Windows.Forms.Label();
            this.lblDieasalAmt = new System.Windows.Forms.Label();
            this.lblTollAmount = new System.Windows.Forms.Label();
            this.lblAmount = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(530, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 26);
            this.label1.TabIndex = 1;
            this.label1.Text = "Driver Invoice";
            // 
            // btnRefersh
            // 
            this.btnRefersh.BackColor = System.Drawing.Color.Teal;
            this.btnRefersh.FlatAppearance.BorderSize = 0;
            this.btnRefersh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefersh.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.btnRefersh.ForeColor = System.Drawing.Color.White;
            this.btnRefersh.Location = new System.Drawing.Point(560, 215);
            this.btnRefersh.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRefersh.Name = "btnRefersh";
            this.btnRefersh.Size = new System.Drawing.Size(236, 56);
            this.btnRefersh.TabIndex = 122;
            this.btnRefersh.Text = "Refersh";
            this.btnRefersh.UseVisualStyleBackColor = false;
            this.btnRefersh.Click += new System.EventHandler(this.btnRefersh_Click);
            // 
            // lblid
            // 
            this.lblid.AutoSize = true;
            this.lblid.Location = new System.Drawing.Point(72, 91);
            this.lblid.Name = "lblid";
            this.lblid.Size = new System.Drawing.Size(45, 20);
            this.lblid.TabIndex = 121;
            this.lblid.Text = "none";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Teal;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(560, 655);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(236, 56);
            this.button2.TabIndex = 120;
            this.button2.Text = "Delete";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.Teal;
            this.btnUpdate.FlatAppearance.BorderSize = 0;
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.btnUpdate.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.Location = new System.Drawing.Point(560, 502);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(236, 56);
            this.btnUpdate.TabIndex = 119;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Teal;
            this.btnAdd.FlatAppearance.BorderSize = 0;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Location = new System.Drawing.Point(560, 349);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(236, 56);
            this.btnAdd.TabIndex = 118;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(803, 49);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(857, 960);
            this.dataGridView2.TabIndex = 117;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            // 
            // dbPaymentMode
            // 
            this.dbPaymentMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.dbPaymentMode.FormattingEnabled = true;
            this.dbPaymentMode.Items.AddRange(new object[] {
            "Mode",
            "Phone Pay",
            "Google Pay",
            "Netbanking",
            "Cash"});
            this.dbPaymentMode.Location = new System.Drawing.Point(314, 764);
            this.dbPaymentMode.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dbPaymentMode.Name = "dbPaymentMode";
            this.dbPaymentMode.Size = new System.Drawing.Size(224, 34);
            this.dbPaymentMode.TabIndex = 116;
            // 
            // txtDriverMobno
            // 
            this.txtDriverMobno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.txtDriverMobno.Location = new System.Drawing.Point(314, 930);
            this.txtDriverMobno.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDriverMobno.Name = "txtDriverMobno";
            this.txtDriverMobno.Size = new System.Drawing.Size(224, 32);
            this.txtDriverMobno.TabIndex = 115;
            // 
            // txtDriverName
            // 
            this.txtDriverName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.txtDriverName.Location = new System.Drawing.Point(314, 882);
            this.txtDriverName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDriverName.Name = "txtDriverName";
            this.txtDriverName.Size = new System.Drawing.Size(224, 32);
            this.txtDriverName.TabIndex = 114;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.label32.Location = new System.Drawing.Point(58, 929);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(180, 26);
            this.label32.TabIndex = 113;
            this.label32.Text = "Driver Mobile No.";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.label33.Location = new System.Drawing.Point(58, 879);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(135, 26);
            this.label33.TabIndex = 112;
            this.label33.Text = "Driver Name";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "dd-MM-yyyy";
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Tai Le", 10.8F, System.Drawing.FontStyle.Bold);
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(602, 91);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(184, 35);
            this.dateTimePicker1.TabIndex = 111;
            // 
            // txtAmountLeft
            // 
            this.txtAmountLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.txtAmountLeft.Location = new System.Drawing.Point(314, 702);
            this.txtAmountLeft.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtAmountLeft.Name = "txtAmountLeft";
            this.txtAmountLeft.Size = new System.Drawing.Size(224, 32);
            this.txtAmountLeft.TabIndex = 110;
            this.txtAmountLeft.TextChanged += new System.EventHandler(this.txtAmountLeft_TextChanged);
            // 
            // txtAmount
            // 
            this.txtAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.txtAmount.Location = new System.Drawing.Point(314, 470);
            this.txtAmount.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(224, 32);
            this.txtAmount.TabIndex = 109;
            this.txtAmount.TextChanged += new System.EventHandler(this.txtAmount_TextChanged);
            // 
            // txtRate
            // 
            this.txtRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.txtRate.Location = new System.Drawing.Point(314, 402);
            this.txtRate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtRate.Name = "txtRate";
            this.txtRate.Size = new System.Drawing.Size(224, 32);
            this.txtRate.TabIndex = 108;
            // 
            // txtQuantity
            // 
            this.txtQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.txtQuantity.Location = new System.Drawing.Point(314, 349);
            this.txtQuantity.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(224, 32);
            this.txtQuantity.TabIndex = 107;
            // 
            // txtDestination
            // 
            this.txtDestination.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.txtDestination.Location = new System.Drawing.Point(314, 298);
            this.txtDestination.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDestination.Name = "txtDestination";
            this.txtDestination.Size = new System.Drawing.Size(224, 32);
            this.txtDestination.TabIndex = 106;
            // 
            // txtPartyName
            // 
            this.txtPartyName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.txtPartyName.Location = new System.Drawing.Point(314, 244);
            this.txtPartyName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPartyName.Name = "txtPartyName";
            this.txtPartyName.Size = new System.Drawing.Size(224, 32);
            this.txtPartyName.TabIndex = 105;
            // 
            // txtTruckNo
            // 
            this.txtTruckNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.txtTruckNo.Location = new System.Drawing.Point(314, 194);
            this.txtTruckNo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTruckNo.Name = "txtTruckNo";
            this.txtTruckNo.Size = new System.Drawing.Size(224, 32);
            this.txtTruckNo.TabIndex = 104;
            // 
            // txtLRNo
            // 
            this.txtLRNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.txtLRNo.Location = new System.Drawing.Point(314, 129);
            this.txtLRNo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtLRNo.Name = "txtLRNo";
            this.txtLRNo.Size = new System.Drawing.Size(224, 32);
            this.txtLRNo.TabIndex = 103;
            // 
            // txtPayPartyName
            // 
            this.txtPayPartyName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.txtPayPartyName.Location = new System.Drawing.Point(314, 822);
            this.txtPayPartyName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPayPartyName.Name = "txtPayPartyName";
            this.txtPayPartyName.Size = new System.Drawing.Size(224, 32);
            this.txtPayPartyName.TabIndex = 102;
            // 
            // txtTripAdv
            // 
            this.txtTripAdv.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.txtTripAdv.Location = new System.Drawing.Point(314, 655);
            this.txtTripAdv.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTripAdv.Name = "txtTripAdv";
            this.txtTripAdv.Size = new System.Drawing.Size(224, 32);
            this.txtTripAdv.TabIndex = 101;
            // 
            // txtDieasalAdv
            // 
            this.txtDieasalAdv.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.txtDieasalAdv.Location = new System.Drawing.Point(314, 592);
            this.txtDieasalAdv.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDieasalAdv.Name = "txtDieasalAdv";
            this.txtDieasalAdv.Size = new System.Drawing.Size(224, 32);
            this.txtDieasalAdv.TabIndex = 100;
            // 
            // txtTollAmount
            // 
            this.txtTollAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.txtTollAmount.Location = new System.Drawing.Point(314, 531);
            this.txtTollAmount.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTollAmount.Name = "txtTollAmount";
            this.txtTollAmount.Size = new System.Drawing.Size(224, 32);
            this.txtTollAmount.TabIndex = 99;
            // 
            // lblPayPartyName
            // 
            this.lblPayPartyName.AutoSize = true;
            this.lblPayPartyName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.lblPayPartyName.Location = new System.Drawing.Point(58, 824);
            this.lblPayPartyName.Name = "lblPayPartyName";
            this.lblPayPartyName.Size = new System.Drawing.Size(221, 26);
            this.lblPayPartyName.TabIndex = 98;
            this.lblPayPartyName.Text = "Payment Party Name";
            // 
            // lblPayMode
            // 
            this.lblPayMode.AutoSize = true;
            this.lblPayMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.lblPayMode.Location = new System.Drawing.Point(58, 764);
            this.lblPayMode.Name = "lblPayMode";
            this.lblPayMode.Size = new System.Drawing.Size(159, 26);
            this.lblPayMode.TabIndex = 97;
            this.lblPayMode.Text = "Payment Mode";
            // 
            // lblAmtLeft
            // 
            this.lblAmtLeft.AutoSize = true;
            this.lblAmtLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.lblAmtLeft.Location = new System.Drawing.Point(58, 701);
            this.lblAmtLeft.Name = "lblAmtLeft";
            this.lblAmtLeft.Size = new System.Drawing.Size(130, 26);
            this.lblAmtLeft.TabIndex = 96;
            this.lblAmtLeft.Text = "Amount Left";
            // 
            // lblTripAdv
            // 
            this.lblTripAdv.AutoSize = true;
            this.lblTripAdv.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.lblTripAdv.Location = new System.Drawing.Point(58, 651);
            this.lblTripAdv.Name = "lblTripAdv";
            this.lblTripAdv.Size = new System.Drawing.Size(139, 26);
            this.lblTripAdv.TabIndex = 95;
            this.lblTripAdv.Text = "Trip Advance";
            // 
            // lblDieasalAmt
            // 
            this.lblDieasalAmt.AutoSize = true;
            this.lblDieasalAmt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.lblDieasalAmt.Location = new System.Drawing.Point(58, 589);
            this.lblDieasalAmt.Name = "lblDieasalAmt";
            this.lblDieasalAmt.Size = new System.Drawing.Size(176, 26);
            this.lblDieasalAmt.TabIndex = 94;
            this.lblDieasalAmt.Text = "Dieasal Advance";
            // 
            // lblTollAmount
            // 
            this.lblTollAmount.AutoSize = true;
            this.lblTollAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.lblTollAmount.Location = new System.Drawing.Point(61, 528);
            this.lblTollAmount.Name = "lblTollAmount";
            this.lblTollAmount.Size = new System.Drawing.Size(128, 26);
            this.lblTollAmount.TabIndex = 93;
            this.lblTollAmount.Text = "Toll Amount";
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.lblAmount.Location = new System.Drawing.Point(61, 469);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(88, 26);
            this.lblAmount.TabIndex = 92;
            this.lblAmount.Text = "Amount";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.label29.Location = new System.Drawing.Point(61, 404);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(58, 26);
            this.label29.TabIndex = 91;
            this.label29.Text = "Rate";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.label28.Location = new System.Drawing.Point(61, 350);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(135, 26);
            this.label28.TabIndex = 90;
            this.label28.Text = "Quantity/Tan";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.label27.Location = new System.Drawing.Point(61, 299);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(121, 26);
            this.label27.TabIndex = 89;
            this.label27.Text = "Destination";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.label26.Location = new System.Drawing.Point(61, 245);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(128, 26);
            this.label26.TabIndex = 88;
            this.label26.Text = "Party Name";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.label25.Location = new System.Drawing.Point(61, 192);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(99, 26);
            this.label25.TabIndex = 87;
            this.label25.Text = "Truck No";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.label24.Location = new System.Drawing.Point(61, 128);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(65, 26);
            this.label24.TabIndex = 86;
            this.label24.Text = "Lr.No";
            // 
            // DriverBill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.btnRefersh);
            this.Controls.Add(this.lblid);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dbPaymentMode);
            this.Controls.Add(this.txtDriverMobno);
            this.Controls.Add(this.txtDriverName);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.txtAmountLeft);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.txtRate);
            this.Controls.Add(this.txtQuantity);
            this.Controls.Add(this.txtDestination);
            this.Controls.Add(this.txtPartyName);
            this.Controls.Add(this.txtTruckNo);
            this.Controls.Add(this.txtLRNo);
            this.Controls.Add(this.txtPayPartyName);
            this.Controls.Add(this.txtTripAdv);
            this.Controls.Add(this.txtDieasalAdv);
            this.Controls.Add(this.txtTollAmount);
            this.Controls.Add(this.lblPayPartyName);
            this.Controls.Add(this.lblPayMode);
            this.Controls.Add(this.lblAmtLeft);
            this.Controls.Add(this.lblTripAdv);
            this.Controls.Add(this.lblDieasalAmt);
            this.Controls.Add(this.lblTollAmount);
            this.Controls.Add(this.lblAmount);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "DriverBill";
            this.Size = new System.Drawing.Size(1675, 1038);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRefersh;
        private System.Windows.Forms.Label lblid;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.ComboBox dbPaymentMode;
        private System.Windows.Forms.TextBox txtDriverMobno;
        private System.Windows.Forms.TextBox txtDriverName;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox txtAmountLeft;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.TextBox txtRate;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.TextBox txtDestination;
        private System.Windows.Forms.TextBox txtPartyName;
        private System.Windows.Forms.TextBox txtTruckNo;
        private System.Windows.Forms.TextBox txtLRNo;
        private System.Windows.Forms.TextBox txtPayPartyName;
        private System.Windows.Forms.TextBox txtTripAdv;
        private System.Windows.Forms.TextBox txtDieasalAdv;
        private System.Windows.Forms.TextBox txtTollAmount;
        private System.Windows.Forms.Label lblPayPartyName;
        private System.Windows.Forms.Label lblPayMode;
        private System.Windows.Forms.Label lblAmtLeft;
        private System.Windows.Forms.Label lblTripAdv;
        private System.Windows.Forms.Label lblDieasalAmt;
        private System.Windows.Forms.Label lblTollAmount;
        private System.Windows.Forms.Label lblAmount;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
    }
}
