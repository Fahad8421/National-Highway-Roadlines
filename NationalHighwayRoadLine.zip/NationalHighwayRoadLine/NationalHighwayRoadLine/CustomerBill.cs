﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace NationalHighwayRoadLine
{
    public partial class CustomerBill : UserControl
    {
        public CustomerBill()
        {
            InitializeComponent();
        }
        public void ClearData()
        {
            txtBID.Text = "";
            txtTNo.Text = "";
            txtDName.Text = "";
            txtTFrom.Text = "";
            txtTTo.Text = "";
            txtPName.Text = "";
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
            txtSubTotal.Text = "0";
            txtDiscount.Text = "0";
            txtFinalTotal.Text = "0";
        }
        public void clearDataOfAddToCard()
        {
            dataGridView1.Refresh();
            txtSrno.Text = "";
            txtDesc.Text = "";
            txtWeigth.Text = "";
            txtRate.Text = "";
        }
        public void LoadData()
        {
            try
            {
                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);

                //DataTable donater = new DataTable();
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter("select BID,Date,TNo,TFrom,TTo,DName,PName,FTotal from tbl_CutBill1 ", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView2.DataSource = dt;
                con.Close();
                dataGridView2.Visible = true;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        int lastid;
        public static int bid;
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string srno, desc, weigth, rate, stot;
                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into tbl_CustBill2(total)values(@total) select @@identity;", con);
                cmd.Parameters.AddWithValue("@total", txtFinalTotal.Text);
                lastid = int.Parse(cmd.ExecuteScalar().ToString());
                for (int row = 0; row < dataGridView1.Rows.Count - 1; row++)
                {
                    srno = dataGridView1.Rows[row].Cells[0].Value.ToString();
                    desc = dataGridView1.Rows[row].Cells[1].Value.ToString();
                    weigth = dataGridView1.Rows[row].Cells[2].Value.ToString();
                    rate = dataGridView1.Rows[row].Cells[3].Value.ToString();
                    // qty =double.Parse( dataGridView1.Rows[row].Cells[4].Value.ToString());
                    //qty = dataGridView1.Rows[row].Cells[4].Value.ToString();
                    stot = dataGridView1.Rows[row].Cells[4].Value.ToString();
                    SqlCommand cmd1 = new SqlCommand("insert into tbl_CutBill1(BID,Date,TNo,TFrom,TTo,DName,PName,Srno,Descrip,Weigth,Rate,STotal,Advance,ftotal) " +
                                                                        "values(@bid,@Date,@TNo,@TFrom,@TTo,@DName,@PName,@Srno,@Descrip,@Weigth,@Rate,@STotal,@Advance,@ftotal)", con);
                    cmd1.Parameters.AddWithValue("@bid", lastid);
                    cmd1.Parameters.AddWithValue("@Date", Convert.ToDateTime(dateTimePicker1.Text));
                    cmd1.Parameters.AddWithValue("@TNo", txtTNo.Text);
                    cmd1.Parameters.AddWithValue("@TFrom", txtTFrom.Text);
                    cmd1.Parameters.AddWithValue("@TTo", txtTTo.Text);
                    cmd1.Parameters.AddWithValue("@DName", txtDName.Text);
                    cmd1.Parameters.AddWithValue("@PName", txtPName.Text);
                    cmd1.Parameters.AddWithValue("@Srno", srno);
                    cmd1.Parameters.AddWithValue("@Descrip", desc);
                    cmd1.Parameters.AddWithValue("@Weigth", weigth);
                    cmd1.Parameters.AddWithValue("@Rate", rate);                    
                    cmd1.Parameters.AddWithValue("@STotal", stot);
                    cmd1.Parameters.AddWithValue("@Advance", txtDiscount.Text);
                    cmd1.Parameters.AddWithValue("@ftotal", txtFinalTotal.Text);
                    cmd1.ExecuteNonQuery();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            
            MessageBox.Show("Record inserted");
            bid = lastid;
            PrintBill obj = new PrintBill();
            obj.Show();
            LoadData();
            ClearData();
            clearDataOfAddToCard();
        }
        int cnt=0;
        private void btnAddToCard_Click(object sender, EventArgs e)
        {
            if (txtSrno.Text == "")
            {
                string msg1 = "Filled do not empty";
                string msg2 = "Product Data";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtSrno.Focus();
                return;
            }
            if (txtDesc.Text == "")
            {
                string msg1 = "Filled do not empty";
                string msg2 = "Add Product";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtDesc.Focus();
                return;
            }
            double r = 0, w = 0;
            r = Convert.ToDouble(txtRate.Text);
            w = Convert.ToDouble(txtWeigth.Text);
            
            cnt++;
            int n = dataGridView1.Rows.Add();
            dataGridView1.Rows[n].Cells[0].Value = txtSrno.Text;
            dataGridView1.Rows[n].Cells[1].Value = txtDesc.Text;
            dataGridView1.Rows[n].Cells[2].Value = txtWeigth.Text;
            dataGridView1.Rows[n].Cells[3].Value = txtRate.Text;
           // dataGridView1.Rows[n].Cells[4].Value = txtqty.Text;
            // dataGridView1.Rows[n].Cells[5].Value = txtRate.Text;
        //    double rate = double.Parse(lblrate.Text);
          //  double qty = double.Parse(txtqty.Text);
            double temp = r * w;

            dataGridView1.Rows[n].Cells[4].Value = temp.ToString();
            double total = double.Parse(txtSubTotal.Text);

            total = total + temp;
            txtSubTotal.Text = total.ToString();
            
            clearDataOfAddToCard();
        }
        double subtot = 0, dis = 0, ftot = 0;
        private void txtFinalTotal_TextChanged(object sender, EventArgs e)
        {
            subtot = Convert.ToDouble(txtSubTotal.Text);
            dis = Convert.ToDouble(txtDiscount.Text);
            ftot = subtot - dis;
            txtFinalTotal.Text = ftot.ToString();   
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = this.dataGridView2.Rows[e.RowIndex];
                    txtBID.Text = row.Cells["BID"].Value.ToString();
                    dateTimePicker1.Text = row.Cells["Date"].Value.ToString();
                    txtTNo.Text = row.Cells["TNo"].Value.ToString();
                    txtTFrom.Text = row.Cells["TFrom"].Value.ToString();
                    txtTTo.Text = row.Cells["TTo"].Value.ToString();
                    txtDName.Text = row.Cells["DName"].Value.ToString();
                    txtPName.Text = row.Cells["PName"].Value.ToString();
                    txtFinalTotal.Text = row.Cells["FTotal"].Value.ToString();
                    btnPrintSmallBill.Visible = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btncacelReport_Click(object sender, EventArgs e)
        {
            crystalReportViewer1.Visible = false;
            dataGridView2.Visible = true;
            btnPrintSmallBill.Visible = false;
        }

        private void btnRefersh_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnPrintSmallBill_Click(object sender, EventArgs e)
        {
            if (txtBID.Text != "")
            {
                bid =Convert.ToInt32(txtBID.Text);
                PrintBill obj = new PrintBill();
                obj.Show();
                return;

            }
            else
            {
                MessageBox.Show("Please select Data from data table ");
                crystalReportViewer1.Visible = false;
                dataGridView2.Visible = true;
            }
        }
    }
}
