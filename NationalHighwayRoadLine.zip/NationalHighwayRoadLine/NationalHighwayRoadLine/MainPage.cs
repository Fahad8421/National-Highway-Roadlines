﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MedicalMngSysem;

namespace NationalHighwayRoadLine
{
    public partial class MainPage : Form
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            panelMini.Height = btnDashboard.Height;
            panelMini.Top = btnDashboard.Top;
            dashBoard1.BringToFront();
        }

        private void btnDriverInvoice_Click(object sender, EventArgs e)
        {
            panelMini.Height = btnDriverInvoice.Height;
            panelMini.Top = btnDriverInvoice.Top;
            driverBill1.BringToFront();
        }

        private void btnCustomerInvoice_Click(object sender, EventArgs e)
        {
            panelMini.Height = btnCustomerInvoice.Height;
            panelMini.Top = btnCustomerInvoice.Top;
            customerBill1.BringToFront();
        }

        private void btnLocalInvoice_Click(object sender, EventArgs e)
        {
            panelMini.Height = btnLocalInvoice.Height;
            panelMini.Top = btnLocalInvoice.Top;
            localBill1.BringToFront();
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            //panelMini.Height = btnReports.Height;
            //panelMini.Top = btnReports.Top;
            //reports1.BringToFront();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panelMini.Height = btnDeveloperInfo.Height;
            panelMini.Top = btnDeveloperInfo.Top;
            developerInfo1.BringToFront();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            panelMini.Height = btnLogout.Height;
            panelMini.Top = btnLogout.Top;
            MessageBox.Show("LogOut");
            this.Hide();
            LoginForm obj = new LoginForm();
            obj.Show();
            //homePage1.BringToFront();
        }
    }
}
