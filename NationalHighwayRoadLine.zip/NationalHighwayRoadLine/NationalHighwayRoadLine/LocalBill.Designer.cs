﻿namespace NationalHighwayRoadLine
{
    partial class LocalBill
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btncacelReport = new System.Windows.Forms.Button();
            this.btnPrintSmallBill = new System.Windows.Forms.Button();
            this.btnRefersh = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridViewSmallBill = new System.Windows.Forms.DataGridView();
            this.txtTotalAmt2 = new System.Windows.Forms.TextBox();
            this.lblBillID = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.txtTanPrice = new System.Windows.Forms.TextBox();
            this.txtWeigth = new System.Windows.Forms.TextBox();
            this.txtMaterialName = new System.Windows.Forms.TextBox();
            this.txtTruckNumber = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.lblbillno = new System.Windows.Forms.Label();
            this.crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSmallBill)).BeginInit();
            this.SuspendLayout();
            // 
            // btncacelReport
            // 
            this.btncacelReport.BackColor = System.Drawing.Color.Teal;
            this.btncacelReport.FlatAppearance.BorderSize = 0;
            this.btncacelReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncacelReport.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.btncacelReport.ForeColor = System.Drawing.Color.White;
            this.btncacelReport.Location = new System.Drawing.Point(622, 881);
            this.btncacelReport.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btncacelReport.Name = "btncacelReport";
            this.btncacelReport.Size = new System.Drawing.Size(236, 56);
            this.btncacelReport.TabIndex = 116;
            this.btncacelReport.Text = "Close Report";
            this.btncacelReport.UseVisualStyleBackColor = false;
            this.btncacelReport.Visible = false;
            this.btncacelReport.Click += new System.EventHandler(this.btncacelReport_Click);
            // 
            // btnPrintSmallBill
            // 
            this.btnPrintSmallBill.BackColor = System.Drawing.Color.Teal;
            this.btnPrintSmallBill.FlatAppearance.BorderSize = 0;
            this.btnPrintSmallBill.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrintSmallBill.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.btnPrintSmallBill.ForeColor = System.Drawing.Color.White;
            this.btnPrintSmallBill.Location = new System.Drawing.Point(343, 881);
            this.btnPrintSmallBill.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnPrintSmallBill.Name = "btnPrintSmallBill";
            this.btnPrintSmallBill.Size = new System.Drawing.Size(236, 56);
            this.btnPrintSmallBill.TabIndex = 115;
            this.btnPrintSmallBill.Text = "Print";
            this.btnPrintSmallBill.UseVisualStyleBackColor = false;
            this.btnPrintSmallBill.Click += new System.EventHandler(this.btnPrintSmallBill_Click);
            // 
            // btnRefersh
            // 
            this.btnRefersh.BackColor = System.Drawing.Color.Teal;
            this.btnRefersh.FlatAppearance.BorderSize = 0;
            this.btnRefersh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefersh.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.btnRefersh.ForeColor = System.Drawing.Color.White;
            this.btnRefersh.Location = new System.Drawing.Point(69, 881);
            this.btnRefersh.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRefersh.Name = "btnRefersh";
            this.btnRefersh.Size = new System.Drawing.Size(236, 56);
            this.btnRefersh.TabIndex = 114;
            this.btnRefersh.Text = "Refersh";
            this.btnRefersh.UseVisualStyleBackColor = false;
            this.btnRefersh.Click += new System.EventHandler(this.btnRefersh_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Teal;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(622, 766);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(236, 56);
            this.button2.TabIndex = 113;
            this.button2.Text = "Delete";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.Teal;
            this.btnUpdate.FlatAppearance.BorderSize = 0;
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.btnUpdate.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.Location = new System.Drawing.Point(343, 766);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(236, 56);
            this.btnUpdate.TabIndex = 112;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Teal;
            this.btnAdd.FlatAppearance.BorderSize = 0;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Location = new System.Drawing.Point(69, 766);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(236, 56);
            this.btnAdd.TabIndex = 111;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(25, 575);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 26);
            this.label1.TabIndex = 110;
            this.label1.Text = "RS";
            // 
            // dataGridViewSmallBill
            // 
            this.dataGridViewSmallBill.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSmallBill.Location = new System.Drawing.Point(865, 69);
            this.dataGridViewSmallBill.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridViewSmallBill.Name = "dataGridViewSmallBill";
            this.dataGridViewSmallBill.RowTemplate.Height = 24;
            this.dataGridViewSmallBill.Size = new System.Drawing.Size(981, 916);
            this.dataGridViewSmallBill.TabIndex = 109;
            this.dataGridViewSmallBill.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewSmallBill_CellClick);
            // 
            // txtTotalAmt2
            // 
            this.txtTotalAmt2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.txtTotalAmt2.Location = new System.Drawing.Point(655, 571);
            this.txtTotalAmt2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTotalAmt2.Multiline = true;
            this.txtTotalAmt2.Name = "txtTotalAmt2";
            this.txtTotalAmt2.Size = new System.Drawing.Size(185, 39);
            this.txtTotalAmt2.TabIndex = 108;
            this.txtTotalAmt2.TextChanged += new System.EventHandler(this.txtTotalAmt2_TextChanged);
            // 
            // lblBillID
            // 
            this.lblBillID.AutoSize = true;
            this.lblBillID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBillID.Location = new System.Drawing.Point(86, 130);
            this.lblBillID.Name = "lblBillID";
            this.lblBillID.Size = new System.Drawing.Size(0, 25);
            this.lblBillID.TabIndex = 107;
            this.lblBillID.Visible = false;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "dd-MM-yyyy";
            this.dateTimePicker2.Font = new System.Drawing.Font("Microsoft Tai Le", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new System.Drawing.Point(584, 100);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(163, 35);
            this.dateTimePicker2.TabIndex = 106;
            // 
            // txtTanPrice
            // 
            this.txtTanPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.txtTanPrice.Location = new System.Drawing.Point(90, 565);
            this.txtTanPrice.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTanPrice.Multiline = true;
            this.txtTanPrice.Name = "txtTanPrice";
            this.txtTanPrice.Size = new System.Drawing.Size(185, 39);
            this.txtTanPrice.TabIndex = 105;
            // 
            // txtWeigth
            // 
            this.txtWeigth.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.txtWeigth.Location = new System.Drawing.Point(26, 489);
            this.txtWeigth.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtWeigth.Multiline = true;
            this.txtWeigth.Name = "txtWeigth";
            this.txtWeigth.Size = new System.Drawing.Size(306, 39);
            this.txtWeigth.TabIndex = 104;
            // 
            // txtMaterialName
            // 
            this.txtMaterialName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.txtMaterialName.Location = new System.Drawing.Point(285, 396);
            this.txtMaterialName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtMaterialName.Multiline = true;
            this.txtMaterialName.Name = "txtMaterialName";
            this.txtMaterialName.Size = new System.Drawing.Size(420, 39);
            this.txtMaterialName.TabIndex = 103;
            // 
            // txtTruckNumber
            // 
            this.txtTruckNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.txtTruckNumber.Location = new System.Drawing.Point(366, 292);
            this.txtTruckNumber.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTruckNumber.Multiline = true;
            this.txtTruckNumber.Name = "txtTruckNumber";
            this.txtTruckNumber.Size = new System.Drawing.Size(386, 39);
            this.txtTruckNumber.TabIndex = 102;
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.txtName.Location = new System.Drawing.Point(115, 209);
            this.txtName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtName.Multiline = true;
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(590, 39);
            this.txtName.TabIndex = 101;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.label68.Location = new System.Drawing.Point(339, 575);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(312, 26);
            this.label68.TabIndex = 100;
            this.label68.Text = "So,Coopration is expeceted.";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.label66.Location = new System.Drawing.Point(471, 499);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(374, 26);
            this.label66.TabIndex = 99;
            this.label66.Text = "tans should be filled. As per tanne";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.label65.Location = new System.Drawing.Point(339, 499);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(127, 26);
            this.label65.TabIndex = 98;
            this.label65.Text = "and weigth";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.label64.Location = new System.Drawing.Point(729, 406);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(105, 26);
            this.label64.TabIndex = 97;
            this.label64.Text = "matterial";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.label61.Location = new System.Drawing.Point(45, 400);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(206, 26);
            this.label61.TabIndex = 96;
            this.label61.Text = "we are sending on";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.label56.Location = new System.Drawing.Point(43, 296);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(289, 26);
            this.label56.TabIndex = 95;
            this.label56.Text = "as per you\'r call,Truck No.";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.label55.Location = new System.Drawing.Point(43, 209);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(62, 26);
            this.label55.TabIndex = 94;
            this.label55.Text = "Shri,";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.label54.Location = new System.Drawing.Point(487, 106);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(84, 26);
            this.label54.TabIndex = 93;
            this.label54.Text = "Date :-";
            // 
            // lblbillno
            // 
            this.lblbillno.AutoSize = true;
            this.lblbillno.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbillno.Location = new System.Drawing.Point(43, 120);
            this.lblbillno.Name = "lblbillno";
            this.lblbillno.Size = new System.Drawing.Size(51, 29);
            this.lblbillno.TabIndex = 92;
            this.lblbillno.Text = "No.";
            this.lblbillno.Visible = false;
            // 
            // crystalReportViewer1
            // 
            this.crystalReportViewer1.ActiveViewIndex = -1;
            this.crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewer1.Cursor = System.Windows.Forms.Cursors.Default;
            this.crystalReportViewer1.DisplayStatusBar = false;
            this.crystalReportViewer1.Location = new System.Drawing.Point(864, 69);
            this.crystalReportViewer1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.crystalReportViewer1.Name = "crystalReportViewer1";
            this.crystalReportViewer1.Size = new System.Drawing.Size(981, 916);
            this.crystalReportViewer1.TabIndex = 117;
            this.crystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None;
            this.crystalReportViewer1.Visible = false;
            // 
            // LocalBill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.crystalReportViewer1);
            this.Controls.Add(this.btncacelReport);
            this.Controls.Add(this.btnPrintSmallBill);
            this.Controls.Add(this.btnRefersh);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridViewSmallBill);
            this.Controls.Add(this.txtTotalAmt2);
            this.Controls.Add(this.lblBillID);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.txtTanPrice);
            this.Controls.Add(this.txtWeigth);
            this.Controls.Add(this.txtMaterialName);
            this.Controls.Add(this.txtTruckNumber);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label68);
            this.Controls.Add(this.label66);
            this.Controls.Add(this.label65);
            this.Controls.Add(this.label64);
            this.Controls.Add(this.label61);
            this.Controls.Add(this.label56);
            this.Controls.Add(this.label55);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.lblbillno);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "LocalBill";
            this.Size = new System.Drawing.Size(1894, 1038);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSmallBill)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btncacelReport;
        private System.Windows.Forms.Button btnPrintSmallBill;
        private System.Windows.Forms.Button btnRefersh;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridViewSmallBill;
        private System.Windows.Forms.TextBox txtTotalAmt2;
        private System.Windows.Forms.Label lblBillID;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.TextBox txtTanPrice;
        private System.Windows.Forms.TextBox txtWeigth;
        private System.Windows.Forms.TextBox txtMaterialName;
        private System.Windows.Forms.TextBox txtTruckNumber;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label lblbillno;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer1;

    }
}
