﻿namespace NationalHighwayRoadLine
{
    partial class MainPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PanelMenu = new System.Windows.Forms.Panel();
            this.panelMini = new System.Windows.Forms.Panel();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnDeveloperInfo = new System.Windows.Forms.Button();
            this.btnLocalInvoice = new System.Windows.Forms.Button();
            this.btnCustomerInvoice = new System.Windows.Forms.Button();
            this.btnDriverInvoice = new System.Windows.Forms.Button();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.PanelLogo = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelData = new System.Windows.Forms.Panel();
            this.driverBill1 = new NationalHighwayRoadLine.DriverBill();
            this.customerBill1 = new NationalHighwayRoadLine.CustomerBill();
            this.localBill1 = new NationalHighwayRoadLine.LocalBill();
            this.reports1 = new NationalHighwayRoadLine.Reports();
            this.developerInfo1 = new NationalHighwayRoadLine.DeveloperInfo();
            this.dashBoard1 = new NationalHighwayRoadLine.DashBoard();
            this.PanelMenu.SuspendLayout();
            this.PanelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelData.SuspendLayout();
            this.SuspendLayout();
            // 
            // PanelMenu
            // 
            this.PanelMenu.BackColor = System.Drawing.Color.Teal;
            this.PanelMenu.Controls.Add(this.panelMini);
            this.PanelMenu.Controls.Add(this.btnLogout);
            this.PanelMenu.Controls.Add(this.btnDeveloperInfo);
            this.PanelMenu.Controls.Add(this.btnLocalInvoice);
            this.PanelMenu.Controls.Add(this.btnCustomerInvoice);
            this.PanelMenu.Controls.Add(this.btnDriverInvoice);
            this.PanelMenu.Controls.Add(this.btnDashboard);
            this.PanelMenu.Controls.Add(this.PanelLogo);
            this.PanelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.PanelMenu.Location = new System.Drawing.Point(0, 0);
            this.PanelMenu.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.PanelMenu.Name = "PanelMenu";
            this.PanelMenu.Size = new System.Drawing.Size(285, 872);
            this.PanelMenu.TabIndex = 1;
            // 
            // panelMini
            // 
            this.panelMini.BackColor = System.Drawing.Color.White;
            this.panelMini.Location = new System.Drawing.Point(1, 176);
            this.panelMini.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelMini.Name = "panelMini";
            this.panelMini.Size = new System.Drawing.Size(11, 81);
            this.panelMini.TabIndex = 11;
            // 
            // btnLogout
            // 
            this.btnLogout.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI Semibold", 11F);
            this.btnLogout.ForeColor = System.Drawing.Color.White;
            this.btnLogout.Image = global::NationalHighwayRoadLine.Properties.Resources.icons8_Logout_24px;
            this.btnLogout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLogout.Location = new System.Drawing.Point(0, 571);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(285, 79);
            this.btnLogout.TabIndex = 10;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnDeveloperInfo
            // 
            this.btnDeveloperInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDeveloperInfo.FlatAppearance.BorderSize = 0;
            this.btnDeveloperInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeveloperInfo.Font = new System.Drawing.Font("Segoe UI Semibold", 11F);
            this.btnDeveloperInfo.ForeColor = System.Drawing.Color.White;
            this.btnDeveloperInfo.Image = global::NationalHighwayRoadLine.Properties.Resources.icons8_about_16px;
            this.btnDeveloperInfo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDeveloperInfo.Location = new System.Drawing.Point(0, 492);
            this.btnDeveloperInfo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnDeveloperInfo.Name = "btnDeveloperInfo";
            this.btnDeveloperInfo.Size = new System.Drawing.Size(285, 79);
            this.btnDeveloperInfo.TabIndex = 9;
            this.btnDeveloperInfo.Text = "Developer Info.";
            this.btnDeveloperInfo.UseVisualStyleBackColor = true;
            this.btnDeveloperInfo.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnLocalInvoice
            // 
            this.btnLocalInvoice.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnLocalInvoice.FlatAppearance.BorderSize = 0;
            this.btnLocalInvoice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLocalInvoice.Font = new System.Drawing.Font("Segoe UI Semibold", 11F);
            this.btnLocalInvoice.ForeColor = System.Drawing.Color.White;
            this.btnLocalInvoice.Image = global::NationalHighwayRoadLine.Properties.Resources.icons8_calculator_16px;
            this.btnLocalInvoice.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLocalInvoice.Location = new System.Drawing.Point(0, 413);
            this.btnLocalInvoice.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnLocalInvoice.Name = "btnLocalInvoice";
            this.btnLocalInvoice.Size = new System.Drawing.Size(285, 79);
            this.btnLocalInvoice.TabIndex = 6;
            this.btnLocalInvoice.Text = "Local Invoice";
            this.btnLocalInvoice.UseVisualStyleBackColor = true;
            this.btnLocalInvoice.Click += new System.EventHandler(this.btnLocalInvoice_Click);
            // 
            // btnCustomerInvoice
            // 
            this.btnCustomerInvoice.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCustomerInvoice.FlatAppearance.BorderSize = 0;
            this.btnCustomerInvoice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCustomerInvoice.Font = new System.Drawing.Font("Segoe UI Semibold", 11F);
            this.btnCustomerInvoice.ForeColor = System.Drawing.Color.White;
            this.btnCustomerInvoice.Image = global::NationalHighwayRoadLine.Properties.Resources.icons8_staff_32px;
            this.btnCustomerInvoice.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCustomerInvoice.Location = new System.Drawing.Point(0, 334);
            this.btnCustomerInvoice.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCustomerInvoice.Name = "btnCustomerInvoice";
            this.btnCustomerInvoice.Size = new System.Drawing.Size(285, 79);
            this.btnCustomerInvoice.TabIndex = 4;
            this.btnCustomerInvoice.Text = "Customer Invoice";
            this.btnCustomerInvoice.UseVisualStyleBackColor = true;
            this.btnCustomerInvoice.Click += new System.EventHandler(this.btnCustomerInvoice_Click);
            // 
            // btnDriverInvoice
            // 
            this.btnDriverInvoice.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDriverInvoice.FlatAppearance.BorderSize = 0;
            this.btnDriverInvoice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDriverInvoice.Font = new System.Drawing.Font("Segoe UI Semibold", 11F);
            this.btnDriverInvoice.ForeColor = System.Drawing.Color.White;
            this.btnDriverInvoice.Image = global::NationalHighwayRoadLine.Properties.Resources.icons8_driver_24px;
            this.btnDriverInvoice.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDriverInvoice.Location = new System.Drawing.Point(0, 255);
            this.btnDriverInvoice.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnDriverInvoice.Name = "btnDriverInvoice";
            this.btnDriverInvoice.Size = new System.Drawing.Size(285, 79);
            this.btnDriverInvoice.TabIndex = 2;
            this.btnDriverInvoice.Text = "Driver Invoice";
            this.btnDriverInvoice.UseVisualStyleBackColor = true;
            this.btnDriverInvoice.Click += new System.EventHandler(this.btnDriverInvoice_Click);
            // 
            // btnDashboard
            // 
            this.btnDashboard.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDashboard.FlatAppearance.BorderSize = 0;
            this.btnDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDashboard.Font = new System.Drawing.Font("Segoe UI Semibold", 11F);
            this.btnDashboard.ForeColor = System.Drawing.Color.White;
            this.btnDashboard.Image = global::NationalHighwayRoadLine.Properties.Resources.icons8_dashboard_layout_24px;
            this.btnDashboard.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDashboard.Location = new System.Drawing.Point(0, 176);
            this.btnDashboard.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(285, 79);
            this.btnDashboard.TabIndex = 1;
            this.btnDashboard.Text = "Dashboard";
            this.btnDashboard.UseVisualStyleBackColor = true;
            this.btnDashboard.Click += new System.EventHandler(this.btnDashboard_Click);
            // 
            // PanelLogo
            // 
            this.PanelLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PanelLogo.Controls.Add(this.pictureBox1);
            this.PanelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelLogo.Location = new System.Drawing.Point(0, 0);
            this.PanelLogo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.PanelLogo.Name = "PanelLogo";
            this.PanelLogo.Size = new System.Drawing.Size(285, 176);
            this.PanelLogo.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::NationalHighwayRoadLine.Properties.Resources.images;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(285, 176);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panelData
            // 
            this.panelData.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panelData.Controls.Add(this.dashBoard1);
            this.panelData.Controls.Add(this.driverBill1);
            this.panelData.Controls.Add(this.customerBill1);
            this.panelData.Controls.Add(this.localBill1);
            this.panelData.Controls.Add(this.reports1);
            this.panelData.Controls.Add(this.developerInfo1);
            this.panelData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelData.Location = new System.Drawing.Point(285, 0);
            this.panelData.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelData.Name = "panelData";
            this.panelData.Size = new System.Drawing.Size(1000, 872);
            this.panelData.TabIndex = 2;
            // 
            // driverBill1
            // 
            this.driverBill1.BackColor = System.Drawing.Color.White;
            this.driverBill1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.driverBill1.Location = new System.Drawing.Point(0, 0);
            this.driverBill1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.driverBill1.Name = "driverBill1";
            this.driverBill1.Size = new System.Drawing.Size(1000, 872);
            this.driverBill1.TabIndex = 4;
            // 
            // customerBill1
            // 
            this.customerBill1.BackColor = System.Drawing.Color.White;
            this.customerBill1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.customerBill1.Location = new System.Drawing.Point(0, 0);
            this.customerBill1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.customerBill1.Name = "customerBill1";
            this.customerBill1.Size = new System.Drawing.Size(1000, 872);
            this.customerBill1.TabIndex = 3;
            // 
            // localBill1
            // 
            this.localBill1.BackColor = System.Drawing.Color.White;
            this.localBill1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.localBill1.Location = new System.Drawing.Point(0, 0);
            this.localBill1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.localBill1.Name = "localBill1";
            this.localBill1.Size = new System.Drawing.Size(1000, 872);
            this.localBill1.TabIndex = 2;
            // 
            // reports1
            // 
            this.reports1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reports1.Location = new System.Drawing.Point(0, 0);
            this.reports1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.reports1.Name = "reports1";
            this.reports1.Size = new System.Drawing.Size(1000, 872);
            this.reports1.TabIndex = 1;
            // 
            // developerInfo1
            // 
            this.developerInfo1.BackColor = System.Drawing.Color.White;
            this.developerInfo1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.developerInfo1.Location = new System.Drawing.Point(0, 0);
            this.developerInfo1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.developerInfo1.Name = "developerInfo1";
            this.developerInfo1.Size = new System.Drawing.Size(1000, 872);
            this.developerInfo1.TabIndex = 0;
            // 
            // dashBoard1
            // 
            this.dashBoard1.BackColor = System.Drawing.Color.White;
            this.dashBoard1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dashBoard1.Location = new System.Drawing.Point(0, 0);
            this.dashBoard1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.dashBoard1.Name = "dashBoard1";
            this.dashBoard1.Size = new System.Drawing.Size(1000, 872);
            this.dashBoard1.TabIndex = 5;
            // 
            // MainPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1285, 872);
            this.Controls.Add(this.panelData);
            this.Controls.Add(this.PanelMenu);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "MainPage";
            this.Text = "MainPage";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.PanelMenu.ResumeLayout(false);
            this.PanelLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelData.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PanelMenu;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnDeveloperInfo;
        private System.Windows.Forms.Button btnLocalInvoice;
        private System.Windows.Forms.Button btnCustomerInvoice;
        private System.Windows.Forms.Button btnDriverInvoice;
        private System.Windows.Forms.Button btnDashboard;
        private System.Windows.Forms.Panel PanelLogo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panelMini;
        private System.Windows.Forms.Panel panelData;
        private LocalBill localBill1;
        private Reports reports1;
        private DeveloperInfo developerInfo1;
        private DriverBill driverBill1;
        private CustomerBill customerBill1;
        private DashBoard dashBoard1;
    }
}