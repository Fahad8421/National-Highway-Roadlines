﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace NationalHighwayRoadLine
{
    public partial class DriverBill : UserControl
    {
        public DriverBill()
        {
            InitializeComponent();
        }
        public void ClearDataOfBill()
        {

            txtLRNo.Text = "";
            txtTruckNo.Text = "";
            txtPartyName.Text = "";
            txtDestination.Text = "";
            txtQuantity.Text = "";
            txtRate.Text = "";
           // txtAmount.Text="0";
            txtTollAmount.Text = "";
            txtDieasalAdv.Text = "";
            txtTripAdv.Text = "";
          //  txtAmountLeft.Text="0";
            dbPaymentMode.Text = "";
            txtPayPartyName.Text = "";
            txtDriverName.Text = "";
            txtDriverMobno.Text = "";
        }
        public void LoadData()
        {
            try
            {
                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);

                //DataTable donater = new DataTable();
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter("select * from tbl_DriverInvo ", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView2.DataSource = dt;
                con.Close();
                dataGridView2.Visible = true;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtLRNo.Text == "")
            {
                string msg1 = "Please Insert LR Number";
                string msg2 = "Billing";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtLRNo.Focus();
                return;
            }
            if (txtTruckNo.Text == "")
            {
                string msg3 = "Please Insert Truck Number";
                string msg4 = "Billing";
                MessageBoxButtons btn2 = MessageBoxButtons.OKCancel;
                DialogResult rs2 = MessageBox.Show(msg3, msg4, btn2, MessageBoxIcon.Error);
                txtTruckNo.Focus();
                return;
            }
            if (txtPartyName.Text == "")
            {
                string msg1 = "Please Insert Part Name";
                string msg2 = "Billing";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtPartyName.Focus();
                return;
            }
            if (txtDestination.Text == "")
            {
                string msg1 = "Please Insert Destination Name";
                string msg2 = "Billing";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtDestination.Focus();
                return;
            }
            if (txtQuantity.Text == "")
            {
                string msg1 = "Please Insert Quantity ";
                string msg2 = "Billing";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtQuantity.Focus();
                return;
            }
            if (txtRate.Text == "")
            {
                string msg1 = "Please Insert Rate";
                string msg2 = "Billing";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtRate.Focus();
                return;
            }
            if (txtAmount.Text == "")
            {
                string msg1 = "Please Enter the Blanck Space of Amount";
                string msg2 = "Billing";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtAmount.Focus();
                return;
            }



            if (txtTollAmount.Text == "")
            {
                string msg1 = "Please Insert Toll Amount";
                string msg2 = "Billing";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtTollAmount.Focus();
                return;
            }
            if (txtDieasalAdv.Text == "")
            {
                string msg1 = "Please InsertDieasal Amount";
                string msg2 = "Billing";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtDieasalAdv.Focus();
                return;
            }
            if (txtAmountLeft.Text == "")
            {
                string msg1 = "Please Enter the Blanck Space of Amount Left";
                string msg2 = "Billing";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtAmountLeft.Focus();
                return;
            }

            if (txtTripAdv.Text == "")
            {
                string msg1 = "Please Insert Trip Advance";
                string msg2 = "Billing";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtLRNo.Focus();
                return;
            }
            if (dbPaymentMode.Text == "Mode")
            {
                string msg1 = "Please Select Payment Mode";
                string msg2 = "Billing";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtLRNo.Focus();
                return;
            }
            if (txtPayPartyName.Text == "")
            {
                string msg1 = "Please Payment Party Name";
                string msg2 = "Billing";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtLRNo.Focus();
                return;
            }

            try
            {
               // SqlConnection con = new SqlConnection();

                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);
               // con.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Imran\Desktop\Transport Management System\TransportManagementSystem\TransportManagementSystem\TransportSys.mdf;Integrated Security=True;User Instance=True";


                string sql = "insert into tbl_DriverInvo values(@Date,@LRNo,@TruckNo,@Partyname,@Destination,@Quantity,@Rate,@Amount,@TollAmount,@DieasalAmount,@TripAdv,@AmountLeft,@PayMode,@PayPartyName,@DriverName,@DriverMobNo)";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@Date",  Convert.ToDateTime(dateTimePicker1.Text));
                cmd.Parameters.AddWithValue("@LRNo", txtLRNo.Text);
                cmd.Parameters.AddWithValue("@TruckNo", txtTruckNo.Text);
                cmd.Parameters.AddWithValue("@Partyname", txtPartyName.Text);
                cmd.Parameters.AddWithValue("@Destination", txtDestination.Text);
                cmd.Parameters.AddWithValue("@Quantity", txtQuantity.Text);
                cmd.Parameters.AddWithValue("@Rate", txtRate.Text);
                cmd.Parameters.AddWithValue("@Amount", txtAmount.Text);
                cmd.Parameters.AddWithValue("@TollAmount", txtTollAmount.Text);
                cmd.Parameters.AddWithValue("@DieasalAmount", txtDieasalAdv.Text);
                cmd.Parameters.AddWithValue("@TripAdv", txtTripAdv.Text);
                cmd.Parameters.AddWithValue("@AmountLeft", txtAmountLeft.Text);
                cmd.Parameters.AddWithValue("@PayMode", dbPaymentMode.Text);
                cmd.Parameters.AddWithValue("@PayPartyName", txtPayPartyName.Text);
                cmd.Parameters.AddWithValue("@DriverName", txtDriverName.Text);
                cmd.Parameters.AddWithValue("@DriverMobNo", txtDriverMobno.Text);
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                int x = cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show(x.ToString() + "Record Insrted");
                 LoadData();
                dataGridView2.Update();
                dataGridView2.Refresh();
                ClearDataOfBill();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnRefersh_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtAmount.Text == "")
            {
                string msg1 = "Please Enter the Blanck Space of Amount";
                string msg2 = "Billing";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtAmount.Focus();
                return;
            }
            if (txtAmountLeft.Text == "")
            {
                string msg1 = "Please Enter the Blanck Space of Amount Left";
                string msg2 = "Billing";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtAmountLeft.Focus();
                return;
            }
            try
            {
                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);
                string sql = "update tbl_DriverInvo set Date=@Date,LRNo=@LRNo,TruckNo=@TruckNo,Partyname=@Partyname,Destination=@Destination,Quantity=@Quantity,Rate=@Rate,Amount=@Amount,TollAmount=@TollAmount,DieasalAmount=@DieasalAmount,TripAdv=@TripAdv,AmountLeft=@AmountLeft,PayMode=@PayMode,PayPartyName=@PayPartyName,DriverName=@DriverName,DriverMobNo=@DriverMobNo where ID='" + lblid.Text + "'";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(dateTimePicker1.Text));
                cmd.Parameters.AddWithValue("@LRNo", txtLRNo.Text);
                cmd.Parameters.AddWithValue("@TruckNo", txtTruckNo.Text);
                cmd.Parameters.AddWithValue("@Partyname", txtPartyName.Text);
                cmd.Parameters.AddWithValue("@Destination", txtDestination.Text);
                cmd.Parameters.AddWithValue("@Quantity", txtQuantity.Text);
                cmd.Parameters.AddWithValue("@Rate", txtRate.Text);
                cmd.Parameters.AddWithValue("@Amount", txtAmount.Text);
                cmd.Parameters.AddWithValue("@TollAmount", txtTollAmount.Text);
                cmd.Parameters.AddWithValue("@DieasalAmount", txtDieasalAdv.Text);
                cmd.Parameters.AddWithValue("@TripAdv", txtTripAdv.Text);
                cmd.Parameters.AddWithValue("@AmountLeft", txtAmountLeft.Text);
                cmd.Parameters.AddWithValue("@PayMode", dbPaymentMode.Text);
                cmd.Parameters.AddWithValue("@PayPartyName", txtPayPartyName.Text);
                cmd.Parameters.AddWithValue("@DriverName", txtDriverName.Text);
                cmd.Parameters.AddWithValue("@DriverMobNo", txtDriverMobno.Text);
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                int x = cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show(x.ToString() + "Record upDated");
                LoadData();
                dataGridView2.Update();
                dataGridView2.Refresh();
                ClearDataOfBill();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = this.dataGridView2.Rows[e.RowIndex];
                    lblid.Text = row.Cells[0].Value.ToString();
                    dateTimePicker1.Text = row.Cells[1].Value.ToString();
                    txtLRNo.Text = row.Cells[2].Value.ToString();
                    txtTruckNo.Text = row.Cells[3].Value.ToString();
                    txtPartyName.Text = row.Cells[4].Value.ToString();
                    txtDestination.Text = row.Cells[5].Value.ToString();
                    txtQuantity.Text = row.Cells[6].Value.ToString();
                    txtRate.Text = row.Cells[7].Value.ToString();
                    txtAmount.Text = row.Cells[8].Value.ToString();
                    txtTollAmount.Text = row.Cells[9].Value.ToString();
                    txtDieasalAdv.Text = row.Cells[10].Value.ToString();
                    txtTripAdv.Text = row.Cells[11].Value.ToString();
                    txtAmountLeft.Text = row.Cells[12].Value.ToString();
                    dbPaymentMode.Text = row.Cells[13].Value.ToString();
                    txtPayPartyName.Text = row.Cells[14].Value.ToString();
                    txtDriverName.Text = row.Cells[15].Value.ToString();
                    txtDriverMobno.Text = row.Cells[16].Value.ToString();
                    lblAmount.Visible = true;
                    txtAmount.Visible = true;
                    lblTollAmount.Visible = true;
                    txtTollAmount.Visible = true;
                    lblDieasalAmt.Visible = true;
                    txtDieasalAdv.Visible = true;
                    lblTripAdv.Visible = true;
                    txtTripAdv.Visible = true;

                    //btnNext.Visible = false;
                    //btnNext2.Visible = true;
                    lblAmtLeft.Visible = true;
                    txtAmountLeft.Visible = true;
                    lblPayMode.Visible = true;
                    dbPaymentMode.Visible = true;
                    lblPayPartyName.Visible = true;
                    txtPayPartyName.Visible = true;
                    //btnclear.Visible = true;
                    // btnAddBillingData.Visible = true;
                    //  btnUpdateBillingData.Visible = true;

                    //btnNext2.Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);

                string sql = "delete from tbl_DriverInvo where ID=@ID";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@ID", lblid.Text);

                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                int x = cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show(x.ToString() + "Record Deleted");
                LoadData();
                dataGridView2.Update();
                dataGridView2.Refresh();
                txtLRNo.Text = "";
                txtTruckNo.Text = "";
                txtPartyName.Text = "";
                txtDestination.Text = "";
                txtQuantity.Text = "";
                txtRate.Text = "";
                //txtAmount.Text = "";
                txtTollAmount.Text = "";
                txtDieasalAdv.Text = "";
                txtTripAdv.Text = "";
                //txtAmountLeft.Text = "";
                dbPaymentMode.Text = "";
                txtPayPartyName.Text = "";

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtAmount_TextChanged(object sender, EventArgs e)
        {
            double add;
            double a = Convert.ToDouble(txtQuantity.Text);
            double b = Convert.ToDouble(txtRate.Text);
            add = a * b;
            txtAmount.Text = add.ToString();
        }

        private void txtAmountLeft_TextChanged(object sender, EventArgs e)
        {
            double a = Convert.ToDouble(txtAmount.Text);
            double b = Convert.ToDouble(txtTollAmount.Text);
            double ad = a + b;
            double a1 = Convert.ToDouble(txtTripAdv.Text);
            double b1 = Convert.ToDouble(txtDieasalAdv.Text);
            double ad2 = a1 + b1;
            double ad3 = ad - ad2;
            txtAmountLeft.Text = ad3.ToString();
        }
    }
}
