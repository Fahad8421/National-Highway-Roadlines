﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace NationalHighwayRoadLine
{
    public partial class DashBoard : UserControl
    {
        public DashBoard()
        {
            InitializeComponent();
        }
        int x = 300, y = 200;
        private void DashBoard_Load(object sender, EventArgs e)
        {
            timer1.Interval = 1;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.SetBounds(x,y,1,1);
            x++;
            if (x >= 600)
            {
                x = 1;
            }
        }
    }
}
