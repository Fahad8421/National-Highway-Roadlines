﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace NationalHighwayRoadLine
{
    public partial class LocalBill : UserControl
    {
        public LocalBill()
        {
            InitializeComponent();
        }
        public void ClearBillingData()
        {
            lblBillID.Text = "";
            txtName.Text = "";
            txtTruckNumber.Text = "";
            txtMaterialName.Text = "";
            txtTanPrice.Text = "";
            // txtTotalAmt.Text = "";
            txtWeigth.Text = "";
        }
        public void LoadSmallBillData()
        {
            try
            {

                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);
                //DataTable donater = new DataTable();
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter("select * from tbl_LocalInvo ", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridViewSmallBill.DataSource = dt;
                con.Close();
                dataGridViewSmallBill.Visible = true;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "")
            {
                string msg1 = "Please Insert Name";
                string msg2 = "Small Billing";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtName.Focus();
                return;
            }
            if (txtTruckNumber.Text == "")
            {
                string msg1 = "Please Truck Number";
                string msg2 = " Small Billing";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtTruckNumber.Focus();
                return;
            }
            if (txtMaterialName.Text == "")
            {
                string msg1 = "Please Enter Material Type";
                string msg2 = " Small Billing";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtMaterialName.Focus();
                return;
            }
            if (txtWeigth.Text == "")
            {
                string msg1 = "Please Weigth";
                string msg2 = " Small Billing";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtWeigth.Focus();
                return;
            }
            if (txtTanPrice.Text == "")
            {
                string msg1 = "Please Enter Tan Price";
                string msg2 = " Small Billing";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtTanPrice.Focus();
                return;
            }
            if (txtTotalAmt2.Text == "")
            {
                string msg1 = "Please Click on blanck Space";
                string msg2 = " Small Billing";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtTotalAmt2.Focus();
                return;
            }

            try
            {
                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);
                
                string sql = "insert into tbl_LocalInvo values(@Date,@Name,@TruckNo,@MaterealName,@Weigth,@PerTanPrice,@Total)";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@Date",Convert.ToDateTime(dateTimePicker2.Text));
                cmd.Parameters.AddWithValue("@Name", txtName.Text);
                cmd.Parameters.AddWithValue("@TruckNo", txtTruckNumber.Text);
                cmd.Parameters.AddWithValue("@MaterealName", txtMaterialName.Text);
                cmd.Parameters.AddWithValue("@Weigth", txtWeigth.Text);
                cmd.Parameters.AddWithValue("@PerTanPrice", txtTanPrice.Text);
                cmd.Parameters.AddWithValue("@Total", txtTotalAmt2.Text);

                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                int x = cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show(x.ToString() + "Record Insrted");
                LoadSmallBillData();
                dataGridViewSmallBill.Update();
                dataGridViewSmallBill.Refresh();
                ClearBillingData();
                btnPrintSmallBill.Visible = true;
                //AddClearData();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                btnPrintSmallBill.Visible = false;
            }
        }

        private void dataGridViewSmallBill_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            lblbillno.Visible = true;
            lblBillID.Visible = true;
            btnPrintSmallBill.Visible = true;
            // btnNext2.Visible = true;
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = this.dataGridViewSmallBill.Rows[e.RowIndex];

                    lblBillID.Text = row.Cells[0].Value.ToString();
                    dateTimePicker2.Text = row.Cells[1].Value.ToString();
                    txtName.Text = row.Cells[2].Value.ToString();
                    txtTruckNumber.Text = row.Cells[3].Value.ToString();
                    txtMaterialName.Text = row.Cells[4].Value.ToString();
                    txtWeigth.Text = row.Cells[5].Value.ToString();
                    txtTanPrice.Text = row.Cells[6].Value.ToString();
                    txtTotalAmt2.Text = row.Cells[7].Value.ToString();
                    //lblAmount.Visible = true;
                    //txtAmount.Visible = true;
                    //lblTollAmount.Visible = true;
                    //txtTollAmount.Visible = true;
                    //lblDieasalAmt.Visible = true;
                    //txtDieasalAdv.Visible = true;
                    //lblTripAdv.Visible = true;
                    //txtTripAdv.Visible = true;

                    ////btnNext.Visible = false;

                    //lblAmtLeft.Visible = true;
                    //txtAmountLeft.Visible = true;
                    //lblPayMode.Visible = true;
                    //dbPaymentMode.Visible = true;
                    //lblPayPartyName.Visible = true;
                    //txtPayPartyName.Visible = true;
                    //btnclear.Visible = true;
                    //btnAddBillingData.Visible = true;
                    //btnUpdateBillingData.Visible = true;


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txtTotalAmt2_TextChanged(object sender, EventArgs e)
        {
             double w = Convert.ToInt32(txtWeigth.Text);
            double p = Convert.ToInt32(txtTanPrice.Text);
            double t = w * p;
            txtTotalAmt2.Text = t.ToString();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);

                string sql = "update tbl_LocalInvo set Date=@Date,Name=@Name,TruckNo=@TruckNo,MaterealName=@MaterealName,Weight=@Weight,PerTanPrice=@PerTanPrice,Total=@Total where ID='" + lblBillID.Text + "'";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(dateTimePicker2.Text));
                cmd.Parameters.AddWithValue("@Name", txtName.Text);
                cmd.Parameters.AddWithValue("@TruckNo", txtTruckNumber.Text);
                cmd.Parameters.AddWithValue("@MaterealName", txtMaterialName.Text);
                cmd.Parameters.AddWithValue("@Weight", txtWeigth.Text);
                cmd.Parameters.AddWithValue("@PerTanPrice", txtTanPrice.Text);
                cmd.Parameters.AddWithValue("@Total", txtTotalAmt2.Text);
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                int x = cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show(x.ToString() + "Record upDated");
                LoadSmallBillData();
                dataGridViewSmallBill.Update();
                dataGridViewSmallBill.Refresh();
                ClearBillingData();
                btnPrintSmallBill.Visible = true;
                //AddClearData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                btnPrintSmallBill.Visible = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);

                string sql = "delete tbl_LocalInvo where ID='" + lblBillID.Text + "'";
                SqlCommand cmd = new SqlCommand(sql, con);


                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                int x = cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show(x.ToString() + "Record Deleted");
                LoadSmallBillData();
                dataGridViewSmallBill.Update();
                dataGridViewSmallBill.Refresh();
                ClearBillingData();
                //AddClearData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnRefersh_Click(object sender, EventArgs e)
        {
            LoadSmallBillData();
        }

        private void btnPrintSmallBill_Click(object sender, EventArgs e)
        {
             if (lblBillID.Text != "")
            {
            try
            {
                crystalReportViewer1.Visible = true;
                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);

                con.Open();
                DataTable dt = new DataTable();
                SqlCommand cmd = new SqlCommand("select * from tbl_LocalInvo where ID='" + lblBillID.Text + "'", con);
                // SqlCommand cmd = new SqlCommand("select * from Sale where ID='15'", con);
                SqlDataAdapter dr = new SqlDataAdapter(cmd);
                dr.Fill(dt);
               ReportLocalBill cr = new ReportLocalBill();
               cr.Database.Tables["tbl_LocalInvo"].SetDataSource(dt);             
                this.crystalReportViewer1.ReportSource = cr;
                btncacelReport.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            return;

            }
             else
             {
                 MessageBox.Show("Please select Data from data table ");
                 crystalReportViewer1.Visible = false;
                 dataGridViewSmallBill.Visible = true;
             }
        }

        private void btncacelReport_Click(object sender, EventArgs e)
        {
            crystalReportViewer1.Visible = false;
            dataGridViewSmallBill.Visible = true;
            btncacelReport.Visible = false;
        }
    }
}
